<?php

$pdfText = $statusMsg = '';
$status = 'error';

// If the form is submitted
if (isset($_POST['submit'])) {
    // If file is selected
    if (!empty($_FILES["pdf_file"]["name"])) {
        // File upload path
        $fileName = basename($_FILES["pdf_file"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);

        // Allow certain file formats
        $allowTypes = array('pdf');
        if (in_array($fileType, $allowTypes)) {
            // Include autoloader file
            include 'vendor/autoload.php';

            // Initialize and load PDF Parser library
            $parser = new \Smalot\PdfParser\Parser();

            // Source PDF file to extract text
            $file = $_FILES["pdf_file"]["tmp_name"];

            // Parse pdf file using Parser library
            $pdf = $parser->parseFile($file);

            // Extract text from PDF
            $pdfText = $pdf->getText();

            // Define the patterns to extract the required information
            $titlePattern = '/^(.*?)TECHNOLOGY OVERVIEW/m';
            $contentPattern = '/TECHNOLOGY OVERVIEW(.*?)APPLICATIONS/m';
            $piPattern = '/PI:\s*(.*?)(\n|$)/';
            $coPiPattern = '/co-PI:\s*(.*?)(\n|$)/';
            $fundedByPattern = '/Funded By:\s*(.*?)(\n|$)/';

            // Initialize variables to store extracted information
            $title = '';
            $content = '';
            $pi = '';
            $coPi = '';
            $fundedBy = '';

            // Match patterns and extract information
            if (preg_match($titlePattern, $pdfText, $titleMatches)) {
                $title = trim($titleMatches[1]);
            }

            if (preg_match($contentPattern, $pdfText, $contentMatches)) {
                $content = trim($contentMatches[1]);
            }

            if (preg_match($piPattern, $pdfText, $piMatches)) {
                $pi = trim($piMatches[1]);
            }

            if (preg_match($coPiPattern, $pdfText, $coPiMatches)) {
                $coPi = trim($coPiMatches[1]);
            }

            if (preg_match($fundedByPattern, $pdfText, $fundedByMatches)) {
                $fundedBy = trim($fundedByMatches[1]);
            }

            // Output the extracted information
            echo "Title: $title<br>";
            echo "Contents: $content<br>";
            echo "PI: $pi<br>";
            echo "co-PI: $coPi<br>";
            echo "Funded By: $fundedBy<br>";

            // Save PDF text content and extracted information to the database
            $db_host = 'localhost:3306';
            $db_user = 'root';
            $db_password = '';
            $db_name = 'phppdf';

            $conn = new mysqli($db_host, $db_user, $db_password, $db_name);
            if ($conn->connect_error) {
                die('Connection failed: ' . $conn->connect_error);
            }

            $content = $conn->real_escape_string($content);
            $title = $conn->real_escape_string($title);
            $pi = $conn->real_escape_string($pi);
            $coPi = $conn->real_escape_string($coPi);
            $fundedBy = $conn->real_escape_string($fundedBy);

            $sql = "INSERT INTO ex_pdf_files (project_name, title, content, pi, co_pi, funded_by) 
                    VALUES ('$fileName', '$title', '$content', '$pi', '$coPi', '$fundedBy')";
            if ($conn->query($sql) === TRUE) {
                echo 'File uploaded and data saved successfully.';
            } else {
                echo 'Error: ' . $sql . '<br>' . $conn->error;
            }

            $conn->close();

            // Add line break
            $pdfText = nl2br($pdfText);
        } else {
            $statusMsg = '<p>Sorry, only PDF file is allowed to upload.</p>';
        }
    } else {
        $statusMsg = '<p>Please select a PDF file to extract text.</p>';
    }
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Extract Text from PDF using PHP </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Stylesheet file -->
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <div class="wrapper">
        <h2>Extract Text from PDF</h2>
        <div class="cw-frm">
        
            <!-- Form fields -->
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-input">
                    <label for="pdf_file">PDF File</label>
                    <input type="file" name="pdf_file" placeholder="Select a PDF file" required="">
                </div>
                <input type="submit" name="submit" class="btn" value="Extract Text">
            </form>
            <!-- Status message -->
            <?php if(!empty($statusMsg)){ ?>
                <div class="status-msg <?php echo $status; ?>"><?php echo $statusMsg; ?></div>
            <?php } ?>
        </div>
    </div>
</div>
<link href="css_home_slide.css" rel="stylesheet" type="text/css"/>
</body>
</html>
