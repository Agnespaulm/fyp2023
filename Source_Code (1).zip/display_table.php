<?php
// Assuming you have a database connection already established.
// Replace 'your_db_hostname', 'your_db_username', 'your_db_password', and 'your_db_name' with your database credentials.

$mysqli = new mysqli('localhost:3306', 'root', '', 'phppdf');

if ($mysqli->connect_error) {
    die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
}

$sql = "SELECT project_name, title, content, member, supervisor, image_path FROM ex_pdf_files";
$result = $mysqli->query($sql);

if ($result->num_rows > 0) {
?>

<!DOCTYPE html>
<html>
<head>
    <title>Display Table</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>

    <!-- FontAwesome library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <!-- Stylesheet file -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/hamburger.css">

    <style>
        
        body {
            background: linear-gradient(135deg, #8E44AD, #FFC19E);
        }
        table {
            border-collapse: collapse;
            width: 100%;
            padding:10px;
        }

        th, td {
            border: 2px solid black;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

/*        tr:hover {
            background-color: #ddd;
        }*/

        .hamburger {
            background-color: white; /* Change the background color to white */
        }

        .menu-icon {
            font-size: 40px;
            margin-left: 10px;
            cursor: pointer;
            color: white; /* Change icon color to white */
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-sm bg-dark navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand text-white" href="Home_ex.php">Home</a>
            <div class="navbar-nav ml-auto">
                <a class="nav-link text-white" href="Logout.php">Logout</a>
            </div>
             <li class="nav-item">
                        <a class="nav-link" href="AboutUs.php">About Us</a>
                    </li>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
                <i class="fas fa-bars text-white"></i> <!-- FontAwesome hamburger icon -->
            </button>
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <!-- Remove the login link -->
            </div>
            <div class="col-md-3">
                <div class="container-fluid">
                    <div class="d-flex" name="frmSearch" method="post">
                        <input class="form-control me-2" type="text" placeholder="Search">
                        <button class="btn btn-primary" type="button">Search</button>
                        <div class="dropdown">
                            <i class="fas fa-bars menu-icon" data-bs-toggle="dropdown"></i>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a class="dropdown-item" href="update.php">Update</a>
                                <a class="dropdown-item" href="delete.php">Delete</a>
                            </div>
                        </div>
                    </div>
                    <div class="welcome-text text-white"> <!-- Change text color to white -->
                        Welcome Admin!
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <script src="script_ham.js"></script>
    <br>
    <table>
        <tr>
            <th>Project Name</th>
            <th>Title</th>
            <th>Content</th>
            <th>Member</th>
            <th>Supervisor</th>
            <th>Image Path</th>
        </tr>

        <?php
        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . $row['project_name'] . '</td>';
            echo '<td>' . $row['title'] . '</td>';
            echo '<td>' . $row['content'] . '</td>';
            echo '<td>' . $row['member'] . '</td>';
            echo '<td>' . $row['supervisor'] . '</td>';
            echo '<td>' . $row['image_path'] . '</td>';
            echo '</tr>';
        }
        ?>
    </table>
</body>
</html>

<?php
} else {
    echo 'No data available.';
}

$mysqli->close();
?>
