<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
<head>
    <meta charset="UTF-8">
    <title>Home_Domains</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
<!--    <link rel="stylesheet" type="text/css" href="domain.css">-->
    <link rel="stylesheet" href="css/domain.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
    <style>
      
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-sm bg-dark navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand text-white" href="Home_ex.php">Home</a>
            <div class="navbar-nav ml-auto">
                <a class="nav-link text-white" href="Logout.php">Logout</a>
            </div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <!-- Remove the login link -->
            </div>
            <div class="col-md-3">
                <div class="container-fluid">
                    <div class="d-flex" name="frmSearch" method="post">
                        <input class="form-control me-2" type="text" placeholder="Search">
                        <button class="btn btn-primary" type="button">Search</button>
                    </div>
                    <div class="welcome-text">
                        Welcome Admin!
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <div class="container-fluid" id="container">
        <h2>Domains</h2>
        <br>
        <div class="row">
            <div class="col-12 col-md-4">
                <a href="extraction_pdf_file.php?domain=Application Development">
                    <div class="card domain-box">
                        <div class="card-body">
                            <img src="images/application-development.png" alt="Image" class="card-image">
                            <h5 class="card-title">Application Development</h5>
                            <p class="card-text">Description of Application Development .</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-12 col-md-4">
                <a href="extraction_pdf_file.php?domain=Artificial Intelligence">
                    <div class="card domain-box">
                        <div class="card-body">
                        
                            <img src="images/ai.jpg" alt="Image" class="card-image">
                            <h5 class="card-title">Artificial Intelligence</h5>
                            <p class="card-text">Description of Artificial Intelligence.</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-12 col-md-4">
                <a href="extraction_pdf_file.php?domain=">
                    <div class="card domain-box">
                        <div class="card-body">
                            <img src="images/dataAnalystics.jpg" alt="Image" class="card-image">
                            <h5 class="card-title">Data Analytics</h5>
                            <p class="card-text">Description of Data Analytics.</p><!--
                        </div>-->
                    </div>
                </a>
            </div>
        </div>
       
        <div class="row">
            <div class="col-12 col-md-4">
                <a href="extraction_pdf_file.php?domain=Fintech">
                    <div class="card domain-box">
                        <div class="card-body">
                            <img src="images/fintech.jpg" alt="Image" class="card-image">
                            <h5 class="card-title">Fintech</h5>
                            <p class="card-text">Description of Fintech.</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-12 col-md-4">
                <a href="extraction_pdf_file.php?domain=Infocomm Security">
                    <div class="card domain-box">
                        <div class="card-body">
                            <img src="images/infocom.jpg" alt="Image" class="card-image">
                            <h5 class="card-title">Infocomm Security</h5>
                            <p class="card-text">Description of Infocomm Security.</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-12 col-md-4">
                <a href="extraction_pdf_file.php?domain=IoT">
                    <div class="card domain-box">
                        <div class="card-body">
                            <img src="images/IoT.jpeg" alt="Image" class="card-image">
                            <h5 class="card-title">IoT</h5>
                            <p class="card-text">Description of IoT.</p>
                        </div>
                    </div>
                </a>
            </div>
        </div>
       
        <div class="row">
            <div class="col-12 col-md-4">
                <a href="extraction_pdf_file.php?domain=Interactive and Digital Medi">
                    <div class="card domain-box">
                        <div class="card-body">
                            <img src="images/INterative Digital.jpg" alt="Image" class="card-image">
                            <h5 class="card-title">Interactive and Digital Media</h5>
                            <p class="card-text">Description of Interactive and Digital Media.</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-12 col-md-4">
                <a href="extraction_pdf_file.php?domain=Network & Systems">
                    <div class="card domain-box">
                        <div class="card-body">
                            <img src="images/network and system.jpg" alt="Image" class="card-image">
                            <h5 class="card-title">Network & Systems</h5>
                            <p class="card-text">Description of Network & Systems.</p>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</body>
</html>
