<?php

$pdfText = $statusMsg = '';
$status = 'error';

// If the form is submitted
if (isset($_POST['submit'])) {
    // If file is selected
    if (!empty($_FILES["pdf_file"]["name"])) {
        // File upload path
        $fileName = basename($_FILES["pdf_file"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);

        // Allow certain file formats
        $allowTypes = array('pdf');
        if (in_array($fileType, $allowTypes)) {
            // Include autoloader file
            include 'vendor/autoload.php';

            // Initialize and load PDF Parser library
            $parser = new \Smalot\PdfParser\Parser();

            // Source PDF file to extract text
            $file = $_FILES["pdf_file"]["tmp_name"];

            // Parse pdf file using Parser library
            $pdf = $parser->parseFile($file);

            // Extract text from PDF
            $pdfText = $pdf->getText();
            $filename = $_FILES["pdf_file"]["name"];

            // Define the patterns to extract title, member, and supervisor
//            $titlePattern ='/\n(.*?) \(Project Overview\)/';
         
            // Define the regular expression pattern to capture all text before "Project Overview"
             

//            $memberPattern = '/Team Members:\n(.*?)\n/';
//            $memberPattern = '/Team Members:\n(.*)\nSupervisor:/';
//            // Define the regular expression pattern to extract team members
//            $memberPattern = '/Team Members:\n(.*?)(?:\n\n|\nSupervisor:|$)/s';
              
//              $memberPattern = '/Team member:\s*([^\n]*)/';
//            // Define the combined pattern for supervisor
              $titlePattern = '/^(.*?)(?=\nProject Overview)/s';
              $memberPattern = '/Team Members:\s*(.*?)\s*(?:\n|$)/s';
             $supervisorPattern = '/\n(.*?) \(supervisor\)|Supervisor:\n(.*)\nThe Istana Building/';

            $title = '';
            $member = '';
            $supervisor = '';
            
            // Match patterns and extract information
            if (preg_match($titlePattern, $pdfText, $titleMatches)) {
                $title = trim($titleMatches[1]);
            }

            if (preg_match($memberPattern, $pdfText, $memberMatches)) {
                $member = trim($memberMatches[1]);
                }
              
            
            if (preg_match($supervisorPattern, $pdfText, $supervisorMatches)) {
            if (!empty($supervisorMatches[1])) {
             $supervisor = trim($supervisorMatches[1]);
             } elseif (!empty($supervisorMatches[2])) {
             $supervisor = trim($supervisorMatches[2]);
             }
             }
             
             
         // Remove the title, member, and supervisor information from the content
            $content = preg_replace($titlePattern, '', $pdfText);
            $content = preg_replace($memberPattern, '', $content);
            $content = preg_replace($supervisorPattern, '', $content);

            // Trim any leading or trailing spaces from the content
            $content = trim($content);

            // Output the extracted information
            echo "Title: $title<br>";
            echo "Member: $member<br>";
            echo "Supervisor: $supervisor<br>";
            echo "Content: $content<br>";

            // Save PDF text content and extracted information to the database
            $db_host = 'localhost:3306';
            $db_user = 'root';
            $db_password = '';
            $db_name = 'phppdf';

            $conn = new mysqli($db_host, $db_user, $db_password, $db_name);
            if ($conn->connect_error) {
                die('Connection failed: ' . $conn->connect_error);
            }

            $content = $conn->real_escape_string($content);
            $title = $conn->real_escape_string($title);
            $member = $conn->real_escape_string($member);
            $supervisor = $conn->real_escape_string($supervisor);

            $sql = "INSERT INTO ex_pdf_files (project_name, title, content, member, supervisor) 
                    VALUES ('$filename', '$title', '$content', '$member', '$supervisor')";
            if ($conn->query($sql) === TRUE) {
                echo 'File uploaded and data saved successfully.';
            } else {
                echo 'Error: ' . $sql . '<br>' . $conn->error;
            }

            $conn->close();

        } else {
            $statusMsg = '<p>Sorry, only PDF file is allowed to upload.</p>';
        }
    } else {
        $statusMsg = '<p>Please select a PDF file to extract text.</p>';
    }

}

?>
<!DOCTYPE html>
<html>
<head>
<title>Extract Text from PDF using PHP </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>

<!-- Stylesheet file -->
<link rel="stylesheet" href="css/style.css">
</head>
<body>
     <nav class="navbar navbar-expand-sm bg-dark navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand text-white" href="Home_ex.php">Home</a>
            <div class="navbar-nav ml-auto">
                <a class="nav-link text-white" href="Logout.php">Logout</a>
            </div>
             <div class="nav-item">
                        <a class="nav-link" href="AboutUs.php">About Us</a>
                    </div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <!-- Remove the login link -->
            </div>
            <div class="col-md-3">
                <div class="container-fluid">
                    <div class="d-flex" name="frmSearch" method="post">
                        <input class="form-control me-2" type="text" placeholder="Search">
                        <button class="btn btn-primary" type="button">Search</button>
                    </div>
                    <div class="welcome-text">
                        Welcome Admin!
                    </div>
                </div>
            </div>
        </div>
    </nav>
<div class="container" id="container">
    <div class="wrapper">
        <h2>Extract Text from PDF</h2>
        <div class="cw-frm">
        
            <!-- Form fields -->
            <form action="display_table.php" method="post" enctype="multipart/form-data">
                <div class="form-input">
                    <label for="pdf_file">PDF File</label>
                    <input type="file" name="pdf_file" placeholder="Select a PDF file" required="">
                </div>
                <input type="submit" name="submit" class="button" value="Extract Text">
            </form>
                        <!-- Status message -->
            <?php if(!empty($statusMsg)){ ?>
                <div class="status-msg <?php echo $status; ?>"><?php echo $statusMsg; ?></div>
            <?php } ?>
        </div>
    </div>

</div>
</body>
</html>


