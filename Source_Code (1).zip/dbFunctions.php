<?php
$db_host = "localhost:3306";
$db_user = "root";
$db_pass = "";
$db_name = "phppdf";
$link = mysqli_connect($db_host,$db_user,$db_pass,$db_name) or 
        die(mysqli_connect_error());
?>

