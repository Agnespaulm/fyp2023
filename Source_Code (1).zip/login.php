<?php
$rememberUsername = "";

// check if cookie is set, then set $rememberUsername to cookie
setcookie('$rememberUsername','admin_name');

// array of allowed usernames
$allowedUsernames = array("Allen", "Agnes", "Sruthi");

if (isset($_POST['submit'])) {
    $username = $_POST['admin_name'];
    $password = $_POST['admin_password'];

    // check if username is allowed
    if (in_array($username, $allowedUsernames)) {
        // perform password validation
        $validPassword = ($password === "fyp123");

        if ($validPassword) {
            // if username and password are valid, redirect to home page
            header("Location: Domain.php");
            exit();
        } else {
            // show access denied message
            $accessDenied = true;
        }
    } else {
        // show access denied message
        $accessDenied = true;
    }
}
?>

<html>
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
    <link href="stylesheets/login.css" rel="stylesheet" type="text/css"/>
</head>
<body>
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="Home_ex.php">Home</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="domain.php">Login</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-3">
                <div class="container">
                    <div class="d-flex" name="frmSearch" method="post">
                        <input class="form-control me-2" type="text" placeholder="Search">
                        <button class="btn btn-primary" type="button">Search</button>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <br>
    <center>
        <form method="post" action="Domain.php">
            <fieldset style="width:400px;">
                <table>
                    <tr>
                        <h3>LOGIN</h3>
                        <td><label for="idUsername">Username:</label></td>
                        <td>
                            <input type="text" id="idUsername" name="admin_name" value="<?php echo $rememberUsername; ?>"/>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="idPassword">Password:</label></td>
                        <td>
                            <input type="password" id="idPassword" name="admin_password" <?php if (isset($accessDenied) && $accessDenied) { echo 'placeholder="Access Denied"'; } ?>/>
                        </td>
                    </tr>
                    <?php if (isset($accessDenied) && $accessDenied) { ?>
                        <tr>
                            <td colspan="2" style="color: red;">Access Denied</td>
                        </tr>
                    <?php } ?>
                    <tr>
                        <td colspan="2" align="left"><input type="checkbox" name="remember">Remember Me</td>
                    </tr>
                    <tr>
                        <td colspan="2" align="center">
                            <input type="submit" value="Login" name="submit"/>
                            
                        </td>
                    </tr>
                </table>
            </fieldset>
        </form>
    </center>
</body>
</html>
