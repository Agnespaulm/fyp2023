document.querySelector('.menu-toggle').addEventListener('click', function () {
    document.querySelector('.menu').classList.toggle('active');
    document.querySelector('.dropdown-menu').classList.toggle('active');
});

// Handle the "Update" button click
document.querySelector('.update-btn').addEventListener('click', function (event) {
    event.preventDefault();
    window.location.href = 'update-page.html'; // Replace 'update-page.html' with your actual update page URL
});

// Handle the "Delete" button click
document.querySelector('.delete-btn').addEventListener('click', function (event) {
    event.preventDefault();
    window.location.href = 'delete-page.html'; // Replace 'delete-page.html' with your actual delete page URL
});
