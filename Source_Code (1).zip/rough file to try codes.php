            // Extract images from PDF and upload to folder
            require_once('tcpdf/tcpdf.php');
            $pdf = new TCPDF();
            $pdf->setSourceFile($file = $_FILES["pdf_file"]["tmp_name"]);
            
            for ($page = 1; $page <= $pdf->getNumPages(); $page++) 
            {
                $pageContent = $pdf->getPageData($page);
                preg_match_all('/XObject\[(\d+) \d+ R\]/', $pageContent, $matches);
            
                foreach ($matches[1] as $xobject) 
                {
                    $imageData = $pdf->getImageData($xobject, true);
                    $imageFilename = 'image_' . $page . '_' . $xobject . '.jpg';
                    file_put_contents($outputFolder . $imageFilename, $imageData);
            
                    // Add the image path to the database
                    $imagePath = $outputFolder . $imageFilename;
                    $stmt = $conn->prepare("INSERT INTO images (image_path) VALUES (?)");
                    $stmt->bind_param("s", $imagePath);
                    $stmt->execute();
                    $stmt->close();
                }
        