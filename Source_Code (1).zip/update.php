<!DOCTYPE html>
<html>
<head>
    <title>Edit Table Content</title>
    <style>
        /* Your styles here */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #8E44AD, #FFC19E);
            margin: 0;
            padding: 0;
        }

        nav {
            background-color: black;
            color: white;
            padding: 30px 0; /* Increased vertical padding */
        }

        nav a {
            text-decoration: none;
            color: white;
            margin-right: 30px;
            font-size: 18px;
        }

        .container {
            padding: 20px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            border: 1px solid black;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

/*        tr:hover {
            background-color: #ddd;
        }*/

        .edit-button {
            margin-top: 10px;
            cursor: pointer;
        }
    </style>
</head>
<body>
<nav>
    <a href="Home_ex"> Home</a>
    <a href="display_table.php">&lt; Table</a>
    <a href="#">&lt; Update</a>
</nav>

<div class="container">
    <h1>Edit Table Content</h1>
    <table>
        <tr>
            <th>Project Name</th>
            <th>Title</th>
            <th>Content</th>
            <th>Member</th>
            <th>Supervisor</th>
            <th>Image Path</th>
        </tr>
        <?php
        // Assuming you have fetched data from the database
        $mysqli = new mysqli('localhost:3306', 'root', '', 'phppdf');

        if ($mysqli->connect_error) {
            die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
        }

        $sql = "SELECT project_name, title, content, member, supervisor, image_path FROM ex_pdf_files";
        $result = $mysqli->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<tr>';
                echo '<td contenteditable="true">' . $row['project_name'] . '</td>';
                echo '<td contenteditable="true">' . $row['title'] . '</td>';
                echo '<td contenteditable="true">' . $row['content'] . '</td>';
                echo '<td contenteditable="true">' . $row['member'] . '</td>';
                echo '<td contenteditable="true">' . $row['supervisor'] . '</td>';
                echo '<td>' . $row['image_path'] . '</td>';
                echo '</tr>';
            }
        } else {
            echo 'No data available.';
        }

        $mysqli->close();
        ?>
    </table>

    <!-- Edit button under the table -->
    <button class="edit-button" onclick="enableEditing()">Edit</button>
</div>

<script>
    function enableEditing() {
        // Enable content editing for all contenteditable cells
        var editableCells = document.querySelectorAll('[contenteditable="true"]');
        for (var i = 0; i < editableCells.length; i++) {
            editableCells[i].setAttribute('contenteditable', 'true');
        }

        // Disable the edit button after enabling editing
        var editButton = document.querySelector('.edit-button');
        editButton.disabled = true;
    }
</script>
</body>
</html>
