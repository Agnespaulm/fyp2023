<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
<!--    <link rel="stylesheet" type="text/css" href="domain.css">-->
    <link rel="stylesheet" href="css/domain.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- ... (meta tags, CSS links, scripts) ... -->
    <style>
        /* Add styles for the About Us section */
        #about-us {
            background-color: #f9f9f9;
            padding: 80px 0;
        }

        #about-us h2 {
            font-size: 36px;
            color: #8E44AD;
            margin-bottom: 20px;
            text-align: center; /* Center-align the heading */
        }

        #about-us .lead {
            font-size: 24px;
            color: #333;
            margin-bottom: 30px;
            max-width: 800px;
            margin: 0 auto;
        }

        #about-us p {
            font-size: 18px;
            color: #555;
            line-height: 1.8;
            margin-bottom: 20px;
        }

        #about-us .highlight-text {
            color: #8E44AD;
            font-weight: bold;
        }

        #about-us .quote {
            font-style: italic;
            font-size: 20px;
            color: #888;
            margin-top: 40px;
        }

        #about-us .quote-author {
            font-weight: bold;
            color: #555;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-sm bg-dark navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand text-white" href="Home_ex.php">Home</a>
            <div class="navbar-nav ml-auto">
                <a class="nav-link text-white" href="Logout.php">Logout</a>
            </div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <!-- Remove the login link -->
            </div>
            <div class="col-md-3">
                <div class="container-fluid">
                    <div class="d-flex" name="frmSearch" method="post">
                        <input class="form-control me-2" type="text" placeholder="Search">
                        <button class="btn btn-primary" type="button">Search</button>
                    </div>
                    <div class="welcome-text">
                        Welcome Admin!
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <!-- About Us section -->
    <section id="about-us" class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center">
                    <h2 class="display-4">Empowering Project Showcase</h2>
                    <p class="lead">
                        Embark on a journey where <span class="highlight-text">innovation merges seamlessly with automation</span>.
                        Our initiative, "Automated Extraction of Project Details for Project Showcase," is dedicated to
                        redefining the presentation and sharing of Final Year Projects (FYPs).
                    </p>
                    <p>
                        Say farewell to manual data extraction and welcome the era of effortless presentations. We are committed
                        to crafting a dynamic platform that revolutionizes the routine task of transferring project details
                        into a captivating voyage of exploration and engagement.
                    </p>
                    <p>
                        Empowered by cutting-edge technologies like PHP, CSS, HTML, and SQL, our solution liberates project
                        presenters to focus on their true passion – their ideas. With an intuitive interface and automated
                        extraction, we envision a future where information flows seamlessly, nurturing an environment where
                        creativity thrives and flourishes.
                    </p>
                    <p>
                        Join us in embracing this <span class="highlight-text">vision of efficiency</span>, where precious time is
                        preserved, presentations radiate brilliance, and knowledge cascades effortlessly. Together, we are shaping
                        the FYP Showcase into an unforgettable experience for both presenters and the inquisitive minds exploring
                        the forefront of innovation.
                    </p>
                    
                </div>
            </div>
        </div>
    </section>

    <!-- Other sections, footer, and scripts ... -->
</body>
</html>
