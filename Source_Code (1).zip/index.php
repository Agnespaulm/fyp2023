<?php

$pdfText = $statusMsg = '';
$status = 'error';

// If the form is submitted
if(isset($_POST['submit']))
{
    // If file is selected
    if(!empty($_FILES["pdf_file"]["name"]))
    {
        // File upload path
		$fileName = basename($_FILES["pdf_file"]["name"]);
		$fileType = pathinfo($fileName, PATHINFO_EXTENSION);
		
		// Allow certain file formats
		$allowTypes = array('pdf');
		if(in_array($fileType, $allowTypes)){
            // Include autoloader file
            include 'vendor/autoload.php';
            
            
            // Initialize and load PDF Parser library
            $parser = new \Smalot\PdfParser\Parser();
            
            // Source PDF file to extract text
            $file = $_FILES["pdf_file"]["tmp_name"];
            
            // Parse pdf file using Parser library
            $pdf = $parser->parseFile($file);
            
            // Extract text from PDF
            $text = $pdf->getText();
            $filename = $_FILES["pdf_file"]["name"];

            // Save PDF text content to the database
               $db_host = 'localhost:3306';
                $db_user = 'root';
                $db_password = '';
                $db_name = 'phppdf';

                $conn = new mysqli($db_host, $db_user, $db_password, $db_name);
                if ($conn->connect_error) {
                    die('Connection failed: ' . $conn->connect_error);
                }

                $text = $conn->real_escape_string($text);

                $sql = "INSERT INTO pdf_files (project_name,text_content) VALUES ('$filename','$text')";
                if ($conn->query($sql) === TRUE) {
                    echo 'File uploaded and data saved successfully.';
                } else {
                    echo 'Error: ' . $sql . '<br>' . $conn->error;
                }

                $conn->close();
            
            // Add line break
            $pdfText = nl2br($text);
        }else{
			$statusMsg = '<p>Sorry, only PDF file is allowed to upload.</p>';
		}
    }else{
		$statusMsg = '<p>Please select a PDF file to extract text.</p>';
	}
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Extract Text from PDF using PHP </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Stylesheet file -->
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <div class="wrapper">
        <h2>Extract Text from PDF</h2>
        <div class="cw-frm">
        
            <!-- Form fields -->
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-input">
                    <label for="pdf_file">PDF File</label>
                    <input type="file" name="pdf_file" placeholder="Select a PDF file" required="">
                </div>
                <input type="submit" name="submit" class="btn" value="Extract Text">
            </form>
                        <!-- Status message -->
            <?php if(!empty($statusMsg)){ ?>
                <div class="status-msg <?php echo $status; ?>"><?php echo $statusMsg; ?></div>
            <?php } ?>
        </div>
    </div>

</div>
</body>
</html>