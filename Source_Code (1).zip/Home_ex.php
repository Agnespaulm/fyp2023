<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
<!--    <link rel="stylesheet" type="text/css" href="css_home_slide.css">-->
    <style>
        /* Add a gradient background */
        body {
            background: linear-gradient(135deg, #8E44AD, #FFC19E);
        }

        /* Style the navigation bar */
        .navbar {
            background-color: #222; /* Change to a lighter black color */
            padding: 20px;
            font-size: 20px;
        }

        /* Style the logo */
        .navbar-brand img {
            height: 60px;
            margin-right: 10px;
        }

        /* Style the navigation links */
        .navbar-nav .nav-link {
            color: white; /* Change link color to white */
            font-weight: bold;
            transition: color 0.3s ease-in-out;
        }

/*        .navbar-nav .nav-link:hover {
            color: #FFC19E;
        }*/

        /* Style the home button */
/*        .home-button {
            background-color: #FFC19E;
            color: black;  Change button text color to black 
            border-radius: 8px;
            padding: 6px 10px;
            transition: background-color 0.3s ease-in-out, color 0.3s ease-in-out;
        }*/

/*        .home-button:hover {
            background-color: #8E44AD;
            color: white;  Change button text color to white 
        }*/

        /* ... (rest of the styles) ... */
    </style>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        // ... (your existing script) ...
    </script>
</head>
<body>
    <nav class="navbar navbar-expand-sm navbar-custom">
        <div class="container-fluid">
            <a class="navbar-brand" href="Home.php">
                <img src="images/rp-logo.png" alt="Logo">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link home-button" href="Home_ex.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="AboutUs.php">About Us</a>
                    </li>
                </ul>
                <div class="col-md-3">
                <div class="container-fluid">
                    <div class="d-flex" name="frmSearch" method="post">
                        <input class="form-control me-2" type="text" placeholder="Search">
                        <button class="btn btn-primary" type="button">Search</button>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </nav>
    <div class="container-fluid">
        <div class="slider-container">
            <!-- ... (slide content) ... -->
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-12 welcome-content">
            <div class="bg-light p-4 rounded">
                <center>
                <h3 class="welcome-message" >Welcome to FYP Website!</h3>
                <h4><img src="images/rp-logo.png" alt="Logo"></h4>
                </center>
            </div>
        </div>
    </div>
</body>
</html>
