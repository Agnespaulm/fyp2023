<?php

$pdfText = $statusMsg = '';
$status = 'error';

// If the form is submitted
if (isset($_POST['submit'])) {
    // If file is selected
    if (!empty($_FILES["pdf_file"]["name"])) {
        // File upload path
        $fileName = basename($_FILES["pdf_file"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);

        // Allow certain file formats
        $allowTypes = array('pdf');
        if (in_array($fileType, $allowTypes)) {
            // Include autoloader file
            include 'vendor/autoload.php';

            // Initialize and load PDF Parser library
            $parser = new \Smalot\PdfParser\Parser();

            // Source PDF file to extract text
            $file = $_FILES["pdf_file"]["tmp_name"];

            // Parse pdf file using Parser library
            $pdf = $parser->parseFile($file);

            // Extract text from PDF
            $text = $pdf->getText();
            $filename = $_FILES["pdf_file"]["name"];

            // Process the extracted text to find specific information
            $title = '';
            $content = '';
            $member = '';
            $supervisor = '';

//            // Search for specific keywords or patterns in the PDF text
//            // Assuming some patterns to find title, member, and supervisor information
////            $titlePattern = '/\n Project Overview (.*)n/i';
//              $titlePattern = '/^(.*?)Project Overview\n/i';
////            $memberPattern = '/Team members:\n(.*)/nSupervisor:/s';
////            $supervisorPattern = '/Supervisor:\n(.*)n/i';
//             $memberPattern = '/Team Members:\n(.*)\nSupervisor:/s';
//            $supervisorPattern = '/Supervisor:\n(.*)/i';
////             Match patterns and extract information
//            if (preg_match($titlePattern, $text, $matches)) {
//                $title = trim($matches[2]);
//            }
//              print_r($titlePattern);
//              
//            if (preg_match($memberPattern, $text, $matches)) {
//                $member = trim($matches[2]);
//            }
//              print_r($memberPattern);
//            if (preg_match($supervisorPattern, $text, $matches)) {
//                $supervisor = trim($matches[2]);
//            }
//             print_r($supervisorPattern);
//             $titlePattern = '/^(.*?)Project Overview\n/i';
//$memberPattern = '/Team Members:\n(.*?)\nSupervisor:/s';
//$supervisorPattern = '/Supervisor:\n(.*)/i';
//$titlePattern = '/%s\s+(.*?)\nProject Overview/i';
//$memberPattern = '/Team Members\n(.*?)\n(.*?)\n/i';
//$supervisorPattern = '/Supervisor\n(.*?)\n/i';
//
//            preg_match(sprintf($titlePattern, $pdfText), $pdfText, $titleMatches);
//           preg_match(sprintf($memberPattern, $pdfText), $pdfText, $memberMatches);
//           preg_match(sprintf($supervisorPattern, $pdfText), $pdfText, $supervisorMatches);
//           
//           // Get the extracted information
//$$title = trim($titleMatches[1] ?? '');
//$members = trim($memberMatches[1] ?? '');
//$supervisor = trim($supervisorMatches[1] ?? '');
//
//// Display or use the extracted information as needed
//echo "Title: " . $title . "<br>";
//echo "Member: " . $member . "<br>";
//echo "Supervisor: " . $supervisor . "<br>";
//
//            // Remove title, member, and supervisor information from the content
//            $content = str_replace([$title, $member, $supervisor], '', $text);
//// Define the patterns to extract title, member, and supervisor
$titlePattern = '/Project Overview\n(.*?):/';
$memberPattern = '/Team Members\n(.*?)\n/';
$supervisorPattern = '/\n(.*?) \(supervisor\)/';

// Match patterns and extract information
if (preg_match($titlePattern, $pdfText, $titleMatches)) {
    $title = trim($titleMatches[1]);
}

if (preg_match($memberPattern, $pdfText, $memberMatches)) {
    $member = trim($memberMatches[1]);
}

if (preg_match($supervisorPattern, $pdfText, $supervisorMatches)) {
    $supervisor = trim($supervisorMatches[1]);
}

// Remove the title, member, and supervisor information from the content
$content = preg_replace($titlePattern, '', $pdfText);
$content = preg_replace($memberPattern, '', $content);
$content = preg_replace($supervisorPattern, '', $content);

// Trim any leading or trailing spaces from the content
$content = trim($content);

// Output the extracted information
echo "Title: $title\n";
echo "Member: $member\n";
echo "Supervisor: $supervisor\n";
echo "Content: $content\n";
            // Save PDF text content and extracted information to the database
            $db_host = 'localhost:3306';
            $db_user = 'root';
            $db_password = '';
            $db_name = 'phppdf';

            $conn = new mysqli($db_host, $db_user, $db_password, $db_name);
            if ($conn->connect_error) {
                die('Connection failed: ' . $conn->connect_error);
            }

            $content = $conn->real_escape_string($content);
            $title = $conn->real_escape_string($title);
            $member = $conn->real_escape_string($member);
            $supervisor = $conn->real_escape_string($supervisor);

            $sql = "INSERT INTO ex_pdf_files (project_name, title, content, member, supervisor) 
                    VALUES ('$filename', '$title', '$content', '$member', '$supervisor')";
            if ($conn->query($sql) === TRUE) {
                echo 'File uploaded and data saved successfully.';
            } else {
                echo 'Error: ' . $sql . '<br>' . $conn->error;
            }

            $conn->close();

            // Add line break
            $pdfText = nl2br($text);
        } else {
            $statusMsg = '<p>Sorry, only PDF file is allowed to upload.</p>';
        }
    } else {
        $statusMsg = '<p>Please select a PDF file to extract text.</p>';
    }
    
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Extract Text from PDF using PHP </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Stylesheet file -->
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <div class="wrapper">
        <h2>Extract Text from PDF</h2>
        <div class="cw-frm">
        
            <!-- Form fields -->
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-input">
                    <label for="pdf_file">PDF File</label>
                    <input type="file" name="pdf_file" placeholder="Select a PDF file" required="">
                </div>
                <input type="submit" name="submit" class="btn" value="Extract Text">
            </form>
                        <!-- Status message -->
            <?php if(!empty($statusMsg)){ ?>
                <div class="status-msg <?php echo $status; ?>"><?php echo $statusMsg; ?></div>
            <?php } ?>
        </div>
    </div>

</div>
</body>
</html>
