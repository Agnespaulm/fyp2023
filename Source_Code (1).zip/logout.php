<?php
// Start the session to access session variables
session_start();

// Set a message to be shown on the login page after logout
$_SESSION['logout_message'] = 'YOU ARE LOGGED OUT !!';

// Unset the session variable that holds the user login status
unset($_SESSION['username']);

// Redirect the user to the login page with the logout message
header("Location: login.php");
exit;
?>
