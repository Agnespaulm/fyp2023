<?php

 

session_start();
// php file that contains the common database connection code
//Check if the form is submitted
include "dbFunctions.php";

 

$username = $_POST['admin_name'];
$password = $_POST['admin_password'];

 

$msg = "";
$queryCheck = "SELECT admin_name FROM admin
          WHERE admin_name='$username'";
$result = mysqli_query($link, $queryCheck);

 

//          AND admin_password = SHA1('$password')";
if(mysqli_num_rows($result)==1){
    $status = false;
}
else{
    $query = "INSERT INTO admin (admin_name,admin_password)VALUES('$username',SHA1('$password'))";
    $status = mysqli_query($link,$query );
}
//$query = "INSERT INTO admin (admin_name,admin_password)VALUES('$username',SHA1('$password'))";
//    $status = mysqli_query($link,$query );
//    
//if($query)
//    echo 'data inserted successfully';

 

if($_SERVER["REQUEST_METHOD"]=="POST"){
    $username = $_POST["admin_name"];
     $password = $_POST["admin_password"];

 

    
//     validate username enad password
     if($username === "admin_name" && $password === "admin_password"){
//         Authentication successfull
          $_SESSION["admin_name"] = $username;
//           Check if "Remember Me" checkbox is checked
          if (isset($_POST["remember"])) {
      // Set a cookie to remember the user
           $cookie_name = "admin_name";
            $cookie_value = $username;
            $cookie_expire = time() + (30 * 24 * 60 * 60); // 30 days
            setcookie($cookie_name, $cookie_value, $cookie_expire);
    }

     // Redirect to the home page or any other authorized page
//    header("Location: home.php");
//    exit;
//     }else{
         // Invalid username or password
    echo "Invalid credentials. Please try again.";
     }
}

 


?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
<head>
<meta charset="UTF-8">
<title></title>
</head>
<body>
<center>

<?php
        echo $msg ;
        ?>
</center>
</body>
</html>
