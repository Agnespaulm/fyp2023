<!DOCTYPE html>
<html>
<head>
    <title>Delete Table Content</title>
    <style>
        /* Your styles here */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #8E44AD, #FFC19E);
            margin: 0;
            padding: 0;
        }

        nav {
            background-color: black;
            color: white;
            padding: 30px 0; /* Increased vertical padding */
        }

        nav a {
            text-decoration: none;
            color: white;
            margin-right: 30px;
            font-size: 18px;
        }

        .container {
            padding: 20px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            border: 1px solid black;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        .delete-button {
            background-color: #FF5733;
            color: white;
            border: none;
            padding: 6px 10px;
            border-radius: 4px;
            cursor: pointer;
        }

/*        .delete-button:hover {
            background-color: #FF8E63;
        }*/
    </style>
</head>
<body>
<nav>
    <a href="Home_ex.php">Home</a>
    <a href="display_table.php">&lt; Table</a>
    <a href="#">&lt; Delete</a>
</nav>

<div class="container">
    <h1>Delete Table Content</h1>
    <table>
        <tr>
            <th>Project Name</th>
            <th>Title</th>
            <th>Content</th>
            <th>Member</th>
            <th>Supervisor</th>
            <th>Image Path</th>
            <th>Action</th> <!-- Added column for action buttons -->
        </tr>
        <?php
        // Assuming you have fetched data from the database
        $mysqli = new mysqli('localhost:3306', 'root', '', 'phppdf');

        if ($mysqli->connect_error) {
            die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
        }

        $sql = "SELECT project_name, title, content, member, supervisor, image_path FROM ex_pdf_files";
        $result = $mysqli->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . $row['project_name'] . '</td>';
                echo '<td>' . $row['title'] . '</td>';
                echo '<td>' . $row['content'] . '</td>';
                echo '<td>' . $row['member'] . '</td>';
                echo '<td>' . $row['supervisor'] . '</td>';
                echo '<td>' . $row['image_path'] . '</td>';
                echo '<td><button class="delete-button" onclick="deleteRow(this)">Delete</button></td>';
                echo '</tr>';
            }
        } else {
            echo 'No data available.';
        }

        $mysqli->close();
        ?>
    </table>
</div>

<script>
    function deleteRow(button) {
        var row = button.parentNode.parentNode;
        row.parentNode.removeChild(row);
    }
</script>
</body>
</html>
